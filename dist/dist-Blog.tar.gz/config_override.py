#!/user/bin
# -*- coding: utf-8 -*-

'''
Override configurations.
'''

__author__ = 'JingxianFan'

configs = {
	'db': {
		'host': '127.0.0.1'
	}
}